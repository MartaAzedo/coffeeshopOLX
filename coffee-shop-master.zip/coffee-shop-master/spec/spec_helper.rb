require 'bundler/setup'
Bundler.setup

require 'cucumber'
RSpec.configure do |config|
end
