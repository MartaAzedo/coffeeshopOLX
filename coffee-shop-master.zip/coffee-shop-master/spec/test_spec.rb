require 'spec_helper'
require "test"

describe Test do
	#pending 'test spec'
	describe '.test' do
		it 'passes' do
			expect(true).to eql(true)
    end
  end
end
