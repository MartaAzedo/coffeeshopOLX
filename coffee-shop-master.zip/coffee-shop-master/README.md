# coffee-shop
Demo Project for qTest Scenario 2.0 + qTest Pulse + Gherkin + Ruby
